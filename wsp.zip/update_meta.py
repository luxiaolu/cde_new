import os
import numpy as np
from cde_functions_new import ExtractVIN

def update_file_path_meta(adaf_obj, file_path, input_dir, output_dir):
    adaf_obj.meta.create_column('DATASET_Output_Path', np.array([output_dir]))
    adaf_obj.meta.create_column('DATASET_Path', np.array([input_dir]))
    adaf_obj.meta.create_column('DATA_Name', np.array([os.path.basename(file_path)]))
    adaf_obj.meta.create_column('DATASET_NAME', np.array([os.path.dirname(os.path.abspath(input_dir))]))
    tmp = os.path.basename(file_path).split("_")
    for i, field in enumerate(tmp):
        adaf_obj.meta.create_column('FILENAME_field_{}'.format(i), np.array([field]))

def dat_adaf_update_meta(adaf_obj, file_path, input_dir, output_dir):
    ExtractVIN(adaf_obj)
    update_file_path_meta(adaf_obj, file_path, input_dir, output_dir)

def sydat_adaf_update_meta(adaf_obj, file_path, input_dir, output_dir):
    update_file_path_meta(adaf_obj, file_path, input_dir, output_dir)
