// leprechauns.cpp : Defines the entry point for the console application.
// @author John Appleseed jappleseed@csu.fullerton.edu
// @author Jane Doe jane.doe.123@csu.fullerton.edu
// @teamname Green Titans

#include "stdafx.h"
#include <iostream>
#include <chrono>
#include <random>

using namespace std;


class RandomNumberGenerator {
public:
	RandomNumberGenerator(int x) :generator(x) {};
	// return a double between -1 and 1
	double randomBetween1and2() {
		return (2.0*generator()) / generator.max() - 1.0;
	}
private:
	minstd_rand0 generator;
};

int N;
// Use a constant random number seed so behavior is consistent from run to run.
int RANDOM_SEED;

int main()
{

	cout << "Enter seed for random number generator: ";
	cin >> RANDOM_SEED;
	RandomNumberGenerator rng(RANDOM_SEED);

	cout << "Enter number of leprechauns: ";
	cin >> N;

	long playtime;
	cout << "Enter game play time (seconds): ";
	cin >> playtime;
	playtime = playtime * 1000; // convert to milliseconds

	double score = 0;
	int nTrapped = 0;

	//
	// CODE FOR INITIALIZING DATA STRUCTURES GOES HERE
	//

	int t = 0; // keep track of number of iterations
	auto start_time0 = chrono::high_resolution_clock::now();
	auto timeSinceStartMS = 0;
	do {

		//
		// CODE FOR A SINGLE ITERATION GOES HERE
		//

		//// You can use the random number generator like so:
		//	double r = rng.randomBetween1and2();
		//  x = x + r*gold;


		t++;
		// code to measure run time
		auto end_time = std::chrono::high_resolution_clock::now();
		auto timeSinceStart = end_time - start_time0;
		timeSinceStartMS = chrono::duration_cast<chrono::milliseconds>(timeSinceStart).count();
	} while (timeSinceStartMS < playtime);

	cout << "Number of iterations = " << t << endl;
	cout << "Number of trapped leprechauns = " << nTrapped << endl;
	cout << "Score = " << (long)score << endl;
	return 0;
}